export class User {
  _id?: String;
  name?: String;
  username?: String;
  email?: String;
  password?: String;
}
