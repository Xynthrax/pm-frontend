export class BerryConfig {
  static layout: string = 'vertical';
  static isCollapse_menu: boolean = false;
  static fontFamily: string = 'poppins'; // Roboto, poppins, inter
}
